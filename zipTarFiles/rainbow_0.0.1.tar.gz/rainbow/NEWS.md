rainbow 0.0.1
All the colors are here!
